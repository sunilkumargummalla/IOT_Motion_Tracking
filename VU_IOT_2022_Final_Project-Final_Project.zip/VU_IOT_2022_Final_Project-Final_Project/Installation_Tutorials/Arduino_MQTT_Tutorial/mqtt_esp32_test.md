# ESP32 MQTT client build #


Select example WiFiMQTT from:
File->Examples->MQTTPubSubClient->WiFiMQTT

This has the includes:
```
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
```

Later you can add them to other sketches to add the same functions, if using an esp8266


Need to setup the WIFI configuration by changing:

```
const char* ssid = "your-ssid";
const char* pass = "your-password";
```
To use the local ssid and password of a wifi AP that is internet connected
( Use your iot router, phone hotspot, or VuGuest credentials or home wifi info )

Run with just the ssid and password changed to test. Once uploaded, the monitor on your ardiono ide should show:
```
/hello world
mqtt received: /hello - world
/hello world
```

Indicating that MQTT is sending a topic /hellp and receiving a topic hello


## Connect to your MQTT broker ##

Now let's update this to use the local server

Update with the local wifi ssid and password that your laptop or pi is using

Replace the line: 

```
while (!client.connect("public.cloud.shiftr.io", 1883)) {
```

with your ipaddr of your laptop or pi mqtt broker
be sure your node red is using the same

```
while (!client.connect("YOUR_LAPTOP_OR_PI_IPADDR", 1883)) {
```

Setup your IOT mqtt broker:

Try this to test that it works using a remote broker.

Next try this with your laptop or pi mqtt server by replacing

```
const char* mqtt_server = "broker.mqtt-dashboard.com";
```

```
const char* mqtt_server = "YOUR_SERVER_IP_ADDRESS";
```
with your laptop or pi's ipaddr

If it does not load press the boot and RTS buttons at the same time on 
the ESP32 MCU and try uploading again.

I also tried sending a message of "load" to the esp32 from the Serial monitor

it should show:

```
/hello world
mqtt received: /hello - world
/hello world
mqtt received: /hello - world
``` 
if it is working setup a mqtt subscriber to see the hello messages in node-red



If the connection does not work it may mean your mqtt server needs a configuration change

[help for mosquitto](http://www.steves-internet-guide.com/mosquitto-broker/)
for mosquitto.conf I added two lines

```
listener 1883
allow_anonymous true
```
to get it to work without security


now try getting node red to convert the published ( outTopic )
to the subscribed (inTopic);

I added a node-red flow to help test the parsing and conversion of mqtt topics
in the Supported_Nodered_Flows.  You can cut and paste the flow in the import
function of nodered management interface:

[MQTT Hello Topic Detector](./Support_Nodered_Flows/MQTT_HelloTopic_SUB.json)

The message comes in and can be parsed as a json string..
You can then make a calulation and create on outgoing mqtt message and even save the value 
to the mysql table.

Let's change the esp32 client to subscribe to "reply" and not "hello" topic

Changing:

```
mqtt.subscribe("/hello", [](const String& payload, const size_t size) {
        Serial.print("/hello ");
        Serial.println(payload);
    });
```

to 

mqtt.subscribe("/reply", [](const String& payload, const size_t size) {
        Serial.print("/reply ");
        Serial.println(payload);
    });
    
Change the flow to add sending the message  back as a /reply topic

