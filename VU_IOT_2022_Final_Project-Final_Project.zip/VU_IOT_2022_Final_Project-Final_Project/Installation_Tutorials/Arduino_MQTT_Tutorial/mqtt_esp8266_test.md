# ESP8266 MQTT client build #


Select example mqtt_esp8266 from:
File->Examples->PubSubClient->mqtt_esp8266

This has the includes:
```
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
```

Later you can add them to other sketches to add the same functions, if using an esp8266


Need to setup the WIFI configuration by changing:

```
const char* ssid = "........";
const char* password = "........";
const char* mqtt_server = "broker.mqtt-dashboard.com";
```
update with the local wifi ssid and password that your laptop or pi is using

Setup your IOT mqtt broker:

Try this to test that it works using a remote broker.

Next try this with your laptop or pi mqtt server by replacing

```
const char* mqtt_server = "broker.mqtt-dashboard.com";
```

```
const char* mqtt_server = "YOUR_SERVER_IP_ADDRESS";
```

with your laptop or pi's ipaddr

If the connection does not work it may mean your mqtt server needs a configuration change

[help for mosquitto](http://www.steves-internet-guide.com/mosquitto-broker/)
for mosquitto.conf I added two lines

```
listener 1883
allow_anonymous true
```
to get it to work without security


now try getting node red to convert the published ( outTopic )
to the subscribed (inTopic);

I added a node-red flow to help test the parsing and conversion of mqtt topics
in the Supported_Nodered_Flows.  You can cut and paste the flow in the import
function of nodered management interface:

[MQTT intopic to outopic converter](./Support_Nodered_Flows/MQTT_Intopic_to_Outopic.json)

The message comes in and can be parsed as a json string..
You can then make a calulation and create on outgoing mqtt message and even save the value 
to the mysql table.

