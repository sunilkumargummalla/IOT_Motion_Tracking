# MQTT Test Client Tutorial #

Prerequisites:
1. working arduino.cc compile for your target board : [Arduino MQTT Tutorial README](./)
2. mqtt library installed on arduino.cc: tools->Manage Libraries... search for EspMQTTClient by Patrick Lapointe.  This package should also install the PubSub package
## Creating MQTT Sketch ##
3. Wifi.h package tools->Manage Libraries... search for Arduino Uno WiFi Dev
In the Arduino.cc select:
Arduino Uno WiFI Dev Ed Library by Arduino



```
File -> Examples -> Adafruit MQTT Library -> mqtt_esp8266
```

this will pop up an edit windo with the example code.

## Configuring the MQTT Sketch ##

Choose either the ESP32 or the ESP8266 path


1. [ESP32 MQTT client build](./mqtt_esp32_test.md)
2. [ESP8266 MQTT client build](./mqtt_esp8266_test.md)




