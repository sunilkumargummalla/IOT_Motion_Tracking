# Database for VU IOT Platform 2022 #

The requested to use MYSQL as the base IOT platforms database.

The images for installation of my sql can be found in 
[https://dev.mysql.com/downloads/](https://dev.mysql.com/downloads/).

Instructions for installing mysql 8.0 on all supported systems are found at
[https://dev.mysql.com/doc/refman/8.0/en/installing.html](https://dev.mysql.com/doc/refman/8.0/en/installing.html)

You will need to create a free oracle account to access the downloads/

Instructions for installing database on
1. [ MACOS ](./mysql_macos_install.md)
1. [ Windows ](./mysql_windows_install.md)
1. [ DietPI ](./mysql_pi_install.md)



