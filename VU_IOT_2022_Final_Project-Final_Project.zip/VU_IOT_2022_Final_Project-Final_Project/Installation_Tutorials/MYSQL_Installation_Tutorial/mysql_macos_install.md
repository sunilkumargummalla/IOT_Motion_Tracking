# Instructions for installing MYSQL database on MACOS laptop #

Use the installer instructions found at:
[https://dev.mysql.com/doc/refman/8.0/en/macos-installation.html](https://dev.mysql.com/doc/refman/8.0/en/macos-installation.html)

I am going to attempt and document any issues installing a [.dmg package](https://dev.mysql.com/downloads/mysql/).

Checking my mac's processor in the "About this Mac" menu, it reported that I am using a: 2.5 GHz Quad-Core Intel Core i7 and MACOS version 12.1.  Therefore I need to use: "macOS 12 (x86, 64-bit), DMG Archive"

I recieved a security message:
“mysql-8.0.31-macos12-x86_64.pkg” cannot be opened because it is from an unidentified developer.

So under preferences I opened the "Security & Privacy window" after clicking ok on the security message.
I then clicked on the lock image to unblock the pkg by clicking open and allow until the installation for MYSQL openned.

Then clicking continue and agree and install buttons until the software installs

I verfied using df in a mac terminal window that I had more than the 807 MB available on the hardrive

I entered a passord for the root user ( be sure to record it somewhere safe)

Next I removed the old .dmg file to make room on my computer.

To check that it was running I used the command 
```
ps aux | grep mysql
```
to check the process was running. The result showed:
```
_mysql           44490   0.4  2.3 34795860 390236   ??  Ss   12:40PM   0:01.52 /usr/local/mysql/bin/mysqld --user=_mysql --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data --plugin-dir=/usr/local/mysql/lib/plugin --log-error=/usr/local/mysql/data/mysqld.local.err --pid-file=/usr/local/mysql/data/mysqld.local.pid --keyring-file-data=/usr/local/mysql/keyring/keyring --early-plugin-load=keyring_file=keyring_file.so
```

From the installation pages
```
MySQL server is now installed, but it is not loaded (or started) by default. Use either launchctl from the command line, or start MySQL by clicking "Start" using the MySQL preference pane. For additional information, see Section 6.3, “Installing a MySQL Launch Daemon”, and Section 6.4, “Installing and Using the MySQL Preference Pane”. Use the MySQL Preference Pane or launchd to configure MySQL to automatically start at bootup.
```

To further test I downloaded [MSQL Shell application](https://dev.mysql.com/downloads/shell/)

Then check for its installation:
```
bash
mysqlsh
```

Once in the mysql shell I ran"
```
\connect --mysql root[:MYSQLPASSWORD]@localhost
```
This connect up mysql on my local machine. Showing:

```
Creating a Classic session to 'root@localhost'
Fetching schema names for auto-completion... Press ^C to stop.
Your MySQL connection id is 8
Server version: 8.0.31 MySQL Community Server - GPL
No default schema selected; type \use <schema> to set one.
```
    
Next we need to Install a base schema for the IOT platform tables.


\connect --mysql root@localhost
```
