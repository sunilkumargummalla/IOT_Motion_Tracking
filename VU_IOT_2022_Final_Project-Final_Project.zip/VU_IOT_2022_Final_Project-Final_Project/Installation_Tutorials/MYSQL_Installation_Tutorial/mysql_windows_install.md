## Instructions for installing MYSQL database on Windows laptop ##

Use the installer found at:
[https://dev.mysql.com/downloads/installer/](https://dev.mysql.com/downloads/installer/)

Please fill in here if you attempt the install