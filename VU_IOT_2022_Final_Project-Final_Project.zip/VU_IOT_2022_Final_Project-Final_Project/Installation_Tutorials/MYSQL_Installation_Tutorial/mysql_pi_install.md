# Instructions for installing mysql database on PI #

Instructions for installing on a generic linux machine can be found:

[https://dev.mysql.com/doc/mysql-shell/8.0/en/mysql-shell-install-linux-quick.html](https://dev.mysql.com/doc/mysql-shell/8.0/en/mysql-shell-install-linux-quick.html)

The software for linux can be found at 
[https://dev.mysql.com/downloads/repo/apt/](https://dev.mysql.com/downloads/repo/apt/)

Copied the current dowload file from the download button
```
https://dev.mysql.com/downloads/file/?id=515363
```

I downloaded the mysql-apt...deb file onto your local machine ( you will need to login with an oracle account ). I downloaded and copied the file to /tmp directory

```
ls mysql-apt-config_0.8.24-1_all.deb
cp mysql-apt-config_0.8.24-1_all.deb /tmp/mysql-apt.deb
```

copy the file to the dietpi using scp ( may need to replace your ssh server on dietpi with openssh )

```

scp -vvv /tmp/mysql-apt.deb root@192.168.8.224:/tmp/mysql-apt.deb

```

You will need to enter password to mak this happen


Now use apt-get to finish the install

```
sudo apt-get install lsb-release
sudo dpkg -i /tmp/mysql-apt.deb
```

I was installing
mysql-8.0 

```
sudo apt-get update
sudo apt-get install mysql-apt-config
```


Suggest installing and testing mysql on your support laptop

### Installing mysql-shell on linux ###

This section has not been finished

The code can be found at:
https://dev.mysql.com/downloads/shell/

Down load the linux-generic .tar file to your local machine.

Copy the .tar file to your dietpi using scp. Change directory to the download directory and run scp.

I used:

```
scp -vvv mysql-shell-8.0.31-linux-glibc2.12-x86-64bit.tar.gz root@192.168.8.224:/tmp/mysql-shell-8.0.31-linux-glibc2.12-x86-64bit.tar.gz
```

untar the files

```
gunzip mysql-shell-8.0.31-linux-glibc2.12-x86-64bit.tar.gz
