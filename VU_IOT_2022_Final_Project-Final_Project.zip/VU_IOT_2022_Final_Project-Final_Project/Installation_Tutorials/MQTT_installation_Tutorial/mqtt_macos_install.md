# Mosquitto install for MacOS#

From [https://www.mosquitto.org/download/](https://www.mosquitto.org/download/)

"Mosquitto can be installed from the homebrew project. See brew.sh and then use"

```
brew install mosquitto
```