# MQTT Install on Windows #

From [https://www.mosquitto.org/download/](https://www.mosquitto.org/download/)

Windows
mosquitto-2.0.15-install-windows-x64.exe (64-bit build, Windows Vista and up, built with Visual Studio Community 2019)
mosquitto-2.0.15-install-windows-x32.exe (32-bit build, Windows Vista and up, built with Visual Studio Community 2019)
Older installers can be found at https://mosquitto.org/files/binary/.

See also README-windows.md after installing.
