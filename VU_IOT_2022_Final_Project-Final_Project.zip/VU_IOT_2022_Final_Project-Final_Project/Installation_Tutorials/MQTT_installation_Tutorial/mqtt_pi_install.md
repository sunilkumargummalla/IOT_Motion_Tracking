
# MQTT for dietpi #

Install MQTT using the dietpi-software using:

```
sudo dietpi-software
```

Browse software and search for the tem "mqtt" 

Select Mosquitto MQTT

Click <ok>

move to the Install function and hit enter

then click ok

it should take a few minutes to install MQTT

If the package is unavailable then you may need to adjust your system

## Alternate install instructions ##
1. install the a apt-utils package at a command line prompt

```
sudo apt install apt-utils
```

Then install mosquitto using apt-get:

```
sudo apt-get install mosquitto
```

This should result in the service installation info of something lie:

```
Created symlink /etc/systemd/system/multi-user.target.wants/mosquitto.service → /lib/systemd/system/mosquitto.service.
Processing triggers for libc-bin (2.31-13+rpt2+rpi1+deb11u5) ...
```