# MQTT Install Tutorial  for VU IOT Platform 2022 #

My preference is to use MQTT as the base IOT platform backend server.

There has been a major growth of MQTT software since 2021:  
[hhttps://mqtt.org/software/](https://mqtt.org/software/)

I still like mosquitto mqtt as the basis of this platform since it is supported
and many devices.  It is also integrated into the dietpi-software systems known modules as module
```
123 Mosquitto: MQTT messaging broker
```
But that install is currently not up to date so the install is failing.
I will include a alternate install procdure in the DietPI support file.

Instructions for installing mosquitto on all supported systems are found at
[https://www.mosquitto.org/](https://www.mosquitto.org/)

Code and test pubsub clients are talked about
[https://github.com/eclipse/mosquitto](https://github.com/eclipse/mosquitto)

Instructions for installing mosquitto on
1. [ MACOS ](./mqtt_macos_install.md)
1. [ Windows ](./mqtt_windows_install.md)
1. [ DietPI ](./mqtt_pi_install.md)


For the lastest mosquitto servers you need to tweek the config files to allow for external access.
You need to find the config file used by your server.
Mosquitto 2.0+ blocks non-local traffic as the default behavior.

From: https://github.com/eclipse/mosquitto/issues/1985
```
To listen on addresses other than localhost, you need to have a config file with 
a "listener" line plus some authentication option. At its most wide-open, 
you could have:

listener 1883
allow_anonymous true

It is, of course, better to restrict the listener to the IP addresses that you need 
and it's often better to use some kind of authentication mechanism rather than 
leaving your server wide open.

If you're upgrading from version 1.6 or earlier, you should look at ChangeLog.txt 
from the installation directory as it has some discussion of breaking changes. 
You may also want to look at https://mosquitto.org/man/mosquitto-conf-5.html
```
