#  node-red for Macos #

Clone node-red to a directory
```
mkdir iot_platform
cd iot_platform
git clone https://github.com/node-red/node-red .
```

Install npm and nodejs on your local machine

```
sudo npm install -g --unsafe-perm node-red
node-red
```

From command line type 
**node-red  **

It will start the node red server.

Open [http://localhost:1880](http://localhost:1880)
