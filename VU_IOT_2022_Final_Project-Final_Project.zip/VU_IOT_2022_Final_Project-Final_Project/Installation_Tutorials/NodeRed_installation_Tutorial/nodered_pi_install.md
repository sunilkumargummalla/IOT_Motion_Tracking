
# Node-red for dietpi #

Install node and node-red using the dietpi-software using:

```
sudo dietpi-software
```

Browse software and search for the tem "node" 
Select node and node-red
Click <ok>

move to the Install function and hit enter
then click ok

it should take a few minutes to install node.js and node-red

## To install node red as a service on PI ##
From [https://nodered.org/docs/getting-started/raspberrypi](https://nodered.org/docs/getting-started/raspberrypi)

1. Install all supporting functions
```
run sudo apt install build-essential git curl

2. Run script "update-nodejs-and-nodered -help"  to see what needs to be done
```
bash <(curl -sL https://raw.githubusercontent.com/node-red/linux-installers/master/deb/update-nodejs-and-nodered -help)
```

```
sudo apt-get install nodejs npm
sudo npm install -g --unsafe-perm node-red
```