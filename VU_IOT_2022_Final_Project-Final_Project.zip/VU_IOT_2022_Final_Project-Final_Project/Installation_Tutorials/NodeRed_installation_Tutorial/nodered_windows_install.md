#  node-red for Windows #


[Nodered windows installation instructions](https://nodered.org/docs/getting-started/windows)

Please submit any details that were not obvious during the installation