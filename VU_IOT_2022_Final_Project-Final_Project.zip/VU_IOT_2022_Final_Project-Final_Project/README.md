# VU_IOT_2022_Final_Project
This is the final project repo for the Villanova University IOT course 2022

The directories will be provide the information and code to replicate the work done 
by the Computer Science Graduate Class: Hands on IOT

Top level directories contain
1. [Installation of Support Software](./Installation_Tutorials)
2. [Major Projects](./Major_Projects)

